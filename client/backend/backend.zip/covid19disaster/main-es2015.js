(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-SG": "./node_modules/moment/locale/en-SG.js",
	"./en-SG.js": "./node_modules/moment/locale/en-SG.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./ga": "./node_modules/moment/locale/ga.js",
	"./ga.js": "./node_modules/moment/locale/ga.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it-ch": "./node_modules/moment/locale/it-ch.js",
	"./it-ch.js": "./node_modules/moment/locale/it-ch.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ku": "./node_modules/moment/locale/ku.js",
	"./ku.js": "./node_modules/moment/locale/ku.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/app.component.html":
/*!**************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/app.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--The content below is only a placeholder and can be replaced.-->\n<router-outlet></router-outlet>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/barrepresent/barrepresent.component.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/barrepresent/barrepresent.component.html ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n  <canvas style=\"font-weight: bold\" height=\"290\" baseChart [datasets]=\"barChartData\" [labels]=\"barChartLabels\" [options]=\"barChartOptions\"\n    [plugins]=\"barChartPlugins\" [legend]=\"barChartLegend\" [chartType]=\"barChartType\">\n  </canvas>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/card-display/card-display.component.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/card-display/card-display.component.html ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class='card'>\n  <div style=\"text-align: center\">\n    <div id=\"maincounter-wrap\" style=\"margin-top:10px\">\n      <h2>{{name}}</h2>\n\n    </div>\n    <div id=\"maincounter-wrap\" style=\"margin-top:10px\">\n      <h2>Coronavirus Cases</h2>\n      <div class=\"maincounter-number\">\n        <span *ngIf=\"data[0].cases.total != undefined\" style=\"color:#aaa\"> {{data[0].cases.total}} </span>\n        <span *ngIf=\"data[0].cases.total == undefined\" style=\"color:#aaa\"> NA</span>\n      </div>\n    </div>\n\n    <div id=\"maincounter-wrap\" style=\"margin-top:10px\">\n      <h2>Deaths</h2>\n      <div class=\"maincounter-number\">\n        <span *ngIf=\"data[0].deaths.total != undefined\" style=\"color: red\">{{data[0].deaths.total }}</span>\n        <span *ngIf=\"!data[0].deaths.total == undefined\" style=\"color: red\">NA</span>\n      </div>\n    </div>\n    <div id=\"maincounter-wrap\" style=\"margin-top:10px;\">\n      <h2>Recovered</h2>\n      <div class=\"maincounter-number\" style=\"color:#8ACA2B \">\n        <span *ngIf=\"data[0].cases.recovered != undefined\">{{data[0].cases.recovered }}</span>\n        <span *ngIf=\"!data[0].cases.recovered == undefined\">NA</span>\n      </div>\n    </div>\n  </div>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/chropleth/chropleth.component.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/chropleth/chropleth.component.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"gmap\" style=\"height: 100%\">\n  <div class=\"zoom-div\">\n    <div class=\"zoom-buttons\" id=\"zoom-in\" style=\"border-bottom-width: 1px;\">\n      <!-- <i class=\"fa fa-plus\" aria-hidden=\"true\"></i> -->+\n    </div>\n    <div class=\"zoom-buttons\" id=\"zoom-out\" style=\"border-top-width: 1px;\">\n      <!-- <i class=\"fa fa-minus\" aria-hidden=\"true\"></i> -->-\n    </div>\n  </div>\n  <svg id=\"map\" style=\"width: 100%; height: 100%; background-color:grey; padding: 0%\"></svg>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/doughnut-chart/doughnut-chart.component.html":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/doughnut-chart/doughnut-chart.component.html ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n  <canvas baseChart [data]=\"doughnutChartData\" [labels]=\"doughnutChartLabels\" [colors]=\"doughnutChartColors\"\n    [chartType]=\"doughnutChartType\"></canvas>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/landing-page/landing-page.component.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/landing-page/landing-page.component.html ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <input type=\"text\" [(ngModel)]=\"countryName\">\r\n<button (click)=\"search()\">Search</button> -->\r\n<link rel=\"stylesheet\" type=\"text/css\"\r\n  href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\">\r\n<div *ngIf=\"send\">\r\n  <div class=\"row\">\r\n    <div class=\"col-lg-3 col-md-3 col-sm-3 \">\r\n      <app-card-display [data]=[doughnut] [name]=[name]></app-card-display>\r\n    </div>\r\n\r\n    <div class=\" col-sm-6 col-md-6 col-lg-6\" style=\"padding: 0%; border-color: #4c4b47; border-width: 2px;\">\r\n      <app-chropleth (pushToParent)=\"receiveMessage($event)\"></app-chropleth>\r\n    </div>\r\n    <div class=\"col-lg-3 col-md-3 col-sm-3\">\r\n      <div class=\"row-cols-1\">\r\n        <app-doughnut-chart [data]=[doughnut]></app-doughnut-chart>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  <div style=\"margin-top: 10px\" *ngIf=\"send\">\r\n    <!-- <div class=\"row\">\r\n\r\n      <div class=\"col-lg-6 col-md-6 col-sm-6 \">\r\n        <div class=\"row-cols-2\">\r\n          <app-barrepresent [countryData]='barChartValue'></app-barrepresent>\r\n        </div>\r\n      </div>\r\n    </div> -->\r\n\r\n    <div style=\"align-content: center\" class='container-lg container-md container-sm'>\r\n      <app-tablerep></app-tablerep>\r\n    </div>\r\n\r\n  </div>\r\n\r\n  <footer id='footer' style=\"background-color: #2c292f\">\r\n    <div class=\"container\">\r\n      <div class=\"row \">\r\n        <div class=\"col-md-4 text-center text-md-left \">\r\n\r\n          <div class=\"py-0\">\r\n            <h3 class=\"my-4 text-white\">Contact<span class=\"mx-2 font-italic text-warning \">Us</span></h3>\r\n\r\n            <!-- <p class=\"footer-links font-weight-bold\">\r\n              <a class=\"text-white\" href=\"#\">Home</a>\r\n              |\r\n              <a class=\"text-white\" href=\"#\">Blog</a>\r\n              |\r\n              <a class=\"text-white\" href=\"#\">About</a>\r\n              |\r\n              <a class=\"text-white\" href=\"#\">Contact</a>\r\n            </p>\r\n            <p class=\"text-light py-4 mb-4\">&copy;2019 Eduonix Learning Solutions Pvt. Ltd.</p> -->\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"col-md-4 text-white text-center text-md-left \">\r\n          <div class=\"py-2 my-4\" style=\"font-weight: bold\">\r\n\r\n\r\n            <div>\r\n              <p><i class=\"fa fa-phone  mx-2 \"></i> +91 99-14926910</p>\r\n            </div>\r\n            <div>\r\n              <p><i class=\"fa fa-envelope  mx-2\"></i><a\r\n                  href=\"mailto:covid19disaster@gmail.com\">covid19disaster@gmail.com</a></p>\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"col-md-4 text-white my-4 text-center text-md-left \">\r\n          <span class=\" font-weight-bold \"><a href=\"#nav\">TOP &uarr;</a></span>\r\n          <!-- <p class=\"text-warning my-2\">\"\" </p> -->\r\n\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </footer>\r\n</div>\r\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/navbar/navbar.component.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/navbar/navbar.component.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <!DOCTYPE html>\n<html lang=\"en\">\n\n<head>\n  <title>Bootstrap Example</title>\n  <meta charset=\"utf-8\" />\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />\n  <link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css\"\n    integrity=\"sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh\" crossorigin=\"anonymous\" />\n  <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js\"></script>\n  <script src=\"//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>\n</head>\n\n<body> -->\n<nav id=\"nav\" class=\"navbar navbar-expand-sm  \">\n  <ul class=\"navbar-nav \">\n    <img src=\"./../../../assets/images/corona.png\" alt=\"\" class=\"rotate\" style=\"height: 40px;width: 40px\">\n    <li class=\"nav-item active \">\n\n      <a class=\"nav-link\" href=\"#\" style=\"font-weight: bolder;align-content: center;color: black\">Corona-Disaster</a>\n\n    </li>\n    <li> <a class=\"nav-link\" href=\"#footer\" style=\"font-weight: bolder;color: black\">Contact-Us </a></li>\n  </ul>\n</nav>\n<!-- </body>\n\n</html> -->\n<mat-spinner style=\"margin-top: 10%; margin-left: 45%;\" *ngIf='!send'></mat-spinner>\n\n<router-outlet *ngIf=\"send\"></router-outlet>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/tablerep/tablerep.component.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/tablerep/tablerep.component.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!DOCTYPE html>\n<html lang=\"en\">\n\n<head>\n  <title>Bootstrap Example</title>\n  <meta charset=\"utf-8\" />\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />\n  <link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css\"\n    integrity=\"sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh\" crossorigin=\"anonymous\" />\n  <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js\"></script>\n  <script src=\"//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>\n\n\n\n</head>\n\n<body>\n  <div><strong>Search </strong> <input type='text' placeholder=\"CountryName/other\" id='search' [(ngModel)]=\"enteredtext\"\n      (change)=\"filterdata(enteredtext)\" /></div>\n  <div class=\"table-responsive \">\n    <table id=\"table\" class=\"table  table-hover\">\n      <thead>\n        <tr>\n          <th>Country or Other</th>\n          <th>Total Cases</th>\n          <th>New Cases</th>\n          <th>Total Deaths</th>\n          <th>New Deaths</th>\n          <th>Recovered</th>\n          <th>Active Cases</th>\n          <th>critical Cases</th>\n\n        </tr>\n      </thead>\n      <tbody>\n        <tr *ngFor=\"let item of Filterdata\">\n          <!-- <th scope=\"row\">3</th> -->\n\n          <td><strong>{{item.country}}</strong></td>\n          <td><strong>{{item.cases.total}}</strong></td>\n          <td><strong>{{item.cases.new}}</strong></td>\n          <td style='background-color: red'><strong>{{item.deaths.total}}</strong></td>\n          <td><strong>{{item.deaths.new}}</strong></td>\n          <td style=\"background-color: green\"><strong>{{item.cases.recovered}}</strong></td>\n          <td><strong>{{item.cases.active}}</strong></td>\n          <td><strong>{{item.cases.critical}}</strong></td>\n\n\n        </tr>\n      </tbody>\n    </table>\n  </div>\n\n</body>\n\n</html>\n<router-outlet></router-outlet>\n"

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _components_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/landing-page/landing-page.component */ "./src/app/components/landing-page/landing-page.component.ts");
/* harmony import */ var _components_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/navbar/navbar.component */ "./src/app/components/navbar/navbar.component.ts");





const routes = [
    { path: "", component: _components_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_4__["NavbarComponent"], children: [{ path: '', component: _components_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_3__["LandingPageComponent"] }] }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let AppComponent = class AppComponent {
    constructor() {
        this.title = 'covid19disaster';
    }
};
AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: __webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/index.js!./src/app/app.component.html"),
        styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
    })
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _components_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/landing-page/landing-page.component */ "./src/app/components/landing-page/landing-page.component.ts");
/* harmony import */ var _components_tablerep_tablerep_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/tablerep/tablerep.component */ "./src/app/components/tablerep/tablerep.component.ts");
/* harmony import */ var _components_doughnut_chart_doughnut_chart_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/doughnut-chart/doughnut-chart.component */ "./src/app/components/doughnut-chart/doughnut-chart.component.ts");
/* harmony import */ var ng2_charts__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ng2-charts */ "./node_modules/ng2-charts/fesm2015/ng2-charts.js");
/* harmony import */ var _components_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/navbar/navbar.component */ "./src/app/components/navbar/navbar.component.ts");
/* harmony import */ var _components_card_display_card_display_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/card-display/card-display.component */ "./src/app/components/card-display/card-display.component.ts");
/* harmony import */ var _components_barrepresent_barrepresent_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./components/barrepresent/barrepresent.component */ "./src/app/components/barrepresent/barrepresent.component.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm2015/animations.js");
/* harmony import */ var _components_chropleth_chropleth_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./components/chropleth/chropleth.component */ "./src/app/components/chropleth/chropleth.component.ts");
/* harmony import */ var _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/progress-spinner */ "./node_modules/@angular/material/esm2015/progress-spinner.js");

















let AppModule = class AppModule {
};
AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        declarations: [
            _app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"],
            _components_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_7__["LandingPageComponent"],
            _components_tablerep_tablerep_component__WEBPACK_IMPORTED_MODULE_8__["TablerepComponent"],
            _components_doughnut_chart_doughnut_chart_component__WEBPACK_IMPORTED_MODULE_9__["DoughnutChartComponent"],
            _components_navbar_navbar_component__WEBPACK_IMPORTED_MODULE_11__["NavbarComponent"],
            _components_card_display_card_display_component__WEBPACK_IMPORTED_MODULE_12__["CardDisplayComponent"],
            _components_barrepresent_barrepresent_component__WEBPACK_IMPORTED_MODULE_13__["BarrepresentComponent"],
            _components_chropleth_chropleth_component__WEBPACK_IMPORTED_MODULE_15__["ChroplethComponent"]
        ],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_4__["AppRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClientModule"],
            ng2_charts__WEBPACK_IMPORTED_MODULE_10__["ChartsModule"],
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_14__["BrowserAnimationsModule"],
            _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_16__["MatProgressSpinnerModule"]
        ],
        providers: [],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "./src/app/components/barrepresent/barrepresent.component.css":
/*!********************************************************************!*\
  !*** ./src/app/components/barrepresent/barrepresent.component.css ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/* div{\r\n\r\n} */\r\ndiv{\r\nwidth:400px;\r\n\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9iYXJyZXByZXNlbnQvYmFycmVwcmVzZW50LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7O0dBRUc7QUFDSDtBQUNBLFdBQVc7O0FBRVgiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL2JhcnJlcHJlc2VudC9iYXJyZXByZXNlbnQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi8qIGRpdntcclxuXHJcbn0gKi9cclxuZGl2e1xyXG53aWR0aDo0MDBweDtcclxuXHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/components/barrepresent/barrepresent.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/components/barrepresent/barrepresent.component.ts ***!
  \*******************************************************************/
/*! exports provided: BarrepresentComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BarrepresentComponent", function() { return BarrepresentComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let BarrepresentComponent = class BarrepresentComponent {
    constructor() {
        this.death = [];
        // barChartOptions: ChartOptions = {
        //   responsive: true,
        // };
        this.barChartOptions = {
            responsive: true,
        };
        this.barChartLabels = [];
        this.barChartType = 'line';
        this.barChartLegend = true;
        this.barChartPlugins = [];
        this.barChartData = [
            {
                data: [], label: 'TotalCases', backgroundColor: 'grey', borderColor: 'black'
            },
            {
                data: [], label: 'Deaths', backgroundColor: ["#FFFFFF", "#FFFFFF", "#FFFFFF", "#FFFFFF", "#FFFFFF"]
            }
        ];
    }
    // names: string[] = [];
    // value: number[] = [];
    ngOnInit() {
        this.countryData.map((data) => {
            this.barChartData[0].data.push(data.cases.total);
            this.barChartLabels.push(data.country);
            this.barChartData[1].data.push(data.deaths.total);
        });
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)
], BarrepresentComponent.prototype, "countryData", void 0);
BarrepresentComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-barrepresent',
        template: __webpack_require__(/*! raw-loader!./barrepresent.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/barrepresent/barrepresent.component.html"),
        styles: [__webpack_require__(/*! ./barrepresent.component.css */ "./src/app/components/barrepresent/barrepresent.component.css")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], BarrepresentComponent);



/***/ }),

/***/ "./src/app/components/card-display/card-display.component.css":
/*!********************************************************************!*\
  !*** ./src/app/components/card-display/card-display.component.css ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/* .card{\r\n\r\n  height : 500px\r\n\r\n} */\r\n.maincounter-number{\r\n\r\n\r\n    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;\r\n    font-size: 25px;\r\n\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9jYXJkLWRpc3BsYXkvY2FyZC1kaXNwbGF5LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7R0FJRztBQUNIOzs7SUFHSSw2RUFBNkU7SUFDN0UsZUFBZTs7QUFFbkIiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL2NhcmQtZGlzcGxheS9jYXJkLWRpc3BsYXkuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi8qIC5jYXJke1xyXG5cclxuICBoZWlnaHQgOiA1MDBweFxyXG5cclxufSAqL1xyXG4ubWFpbmNvdW50ZXItbnVtYmVye1xyXG5cclxuXHJcbiAgICBmb250LWZhbWlseTogJ0dpbGwgU2FucycsICdHaWxsIFNhbnMgTVQnLCBDYWxpYnJpLCAnVHJlYnVjaGV0IE1TJywgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxuXHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/components/card-display/card-display.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/components/card-display/card-display.component.ts ***!
  \*******************************************************************/
/*! exports provided: CardDisplayComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CardDisplayComponent", function() { return CardDisplayComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let CardDisplayComponent = class CardDisplayComponent {
    constructor() { }
    ngOnInit() {
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], CardDisplayComponent.prototype, "data", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
], CardDisplayComponent.prototype, "name", void 0);
CardDisplayComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-card-display',
        template: __webpack_require__(/*! raw-loader!./card-display.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/card-display/card-display.component.html"),
        styles: [__webpack_require__(/*! ./card-display.component.css */ "./src/app/components/card-display/card-display.component.css")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], CardDisplayComponent);



/***/ }),

/***/ "./src/app/components/chropleth/chropleth.component.css":
/*!**************************************************************!*\
  !*** ./src/app/components/chropleth/chropleth.component.css ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".cards-text{\r\n\tfont-family: Arial, Helvetica, sans-serif;\r\n\ttext-align: center;\r\n\tcolor: cornsilk;\r\n\tfont-weight: bold;\r\n}\r\n\r\n.zoom-div{\r\nposition: absolute;\r\nbox-shadow: 0px 0px 10px 0px #888888;\r\ntop : 15px;\r\nleft : 15px;\r\n}\r\n\r\n@media screen and (max-width: 300px) {\r\n #gmap {\r\n   height : 400px\r\n }\r\n}\r\n\r\n.zoom-buttons{\r\n\tbackground-color: #6d6c65;\r\n\toutline: none;\r\n\theight: 40px;\r\n\twidth: 40px;\r\n\tborder-style: solid;\r\n\tborder-width: 2px;\r\n\tborder-color: whitesmoke;\r\n\tcolor: whitesmoke;\r\n\tfont-size: 25px;\r\n\tfont-weight: 500;\r\n\ttext-align: center;\r\n}\r\n\r\n.zoom-buttons:hover{\r\n\tbackground-color: #ed8342;\r\n\tcursor : pointer;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9jaHJvcGxldGgvY2hyb3BsZXRoLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Q0FDQyx5Q0FBeUM7Q0FDekMsa0JBQWtCO0NBQ2xCLGVBQWU7Q0FDZixpQkFBaUI7QUFDbEI7O0FBRUE7QUFDQSxrQkFBa0I7QUFDbEIsb0NBQW9DO0FBQ3BDLFVBQVU7QUFDVixXQUFXO0FBQ1g7O0FBRUE7Q0FDQztHQUNFO0NBQ0Y7QUFDRDs7QUFFQTtDQUNDLHlCQUF5QjtDQUN6QixhQUFhO0NBQ2IsWUFBWTtDQUNaLFdBQVc7Q0FDWCxtQkFBbUI7Q0FDbkIsaUJBQWlCO0NBQ2pCLHdCQUF3QjtDQUN4QixpQkFBaUI7Q0FDakIsZUFBZTtDQUNmLGdCQUFnQjtDQUNoQixrQkFBa0I7QUFDbkI7O0FBRUE7Q0FDQyx5QkFBeUI7Q0FDekIsZ0JBQWdCO0FBQ2pCIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9jaHJvcGxldGgvY2hyb3BsZXRoLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2FyZHMtdGV4dHtcclxuXHRmb250LWZhbWlseTogQXJpYWwsIEhlbHZldGljYSwgc2Fucy1zZXJpZjtcclxuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0Y29sb3I6IGNvcm5zaWxrO1xyXG5cdGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcblxyXG4uem9vbS1kaXZ7XHJcbnBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuYm94LXNoYWRvdzogMHB4IDBweCAxMHB4IDBweCAjODg4ODg4O1xyXG50b3AgOiAxNXB4O1xyXG5sZWZ0IDogMTVweDtcclxufVxyXG5cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMzAwcHgpIHtcclxuICNnbWFwIHtcclxuICAgaGVpZ2h0IDogNDAwcHhcclxuIH1cclxufVxyXG5cclxuLnpvb20tYnV0dG9uc3tcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAjNmQ2YzY1O1xyXG5cdG91dGxpbmU6IG5vbmU7XHJcblx0aGVpZ2h0OiA0MHB4O1xyXG5cdHdpZHRoOiA0MHB4O1xyXG5cdGJvcmRlci1zdHlsZTogc29saWQ7XHJcblx0Ym9yZGVyLXdpZHRoOiAycHg7XHJcblx0Ym9yZGVyLWNvbG9yOiB3aGl0ZXNtb2tlO1xyXG5cdGNvbG9yOiB3aGl0ZXNtb2tlO1xyXG5cdGZvbnQtc2l6ZTogMjVweDtcclxuXHRmb250LXdlaWdodDogNTAwO1xyXG5cdHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLnpvb20tYnV0dG9uczpob3ZlcntcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAjZWQ4MzQyO1xyXG5cdGN1cnNvciA6IHBvaW50ZXI7XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/components/chropleth/chropleth.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/components/chropleth/chropleth.component.ts ***!
  \*************************************************************/
/*! exports provided: ChroplethComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChroplethComponent", function() { return ChroplethComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _currentlocation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../currentlocation */ "./src/app/components/currentlocation.ts");
/* harmony import */ var d3__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! d3 */ "./node_modules/d3/index.js");
/* harmony import */ var topojson__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! topojson */ "./node_modules/topojson/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");






let ChroplethComponent = class ChroplethComponent {
    constructor(http) {
        this.http = http;
        this.pushToParent = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        // inputData : any;
        this.currLocation = new _currentlocation__WEBPACK_IMPORTED_MODULE_2__["CurrentLocation"];
    }
    sendCountry(d) {
        this.pushToParent.emit(d);
    }
    ngOnInit() {
        this.isWait = true;
        // this.service.getHotSpots().subscribe(data => {
        //   console.log(data);
        //   this.inputData = data;
        // })
        let style = window.getComputedStyle(document.querySelector("#map"));
        let width = parseFloat(style.width.replace("px", ""));
        let height = parseFloat(style.height.replace("px", ""));
        var projection = d3__WEBPACK_IMPORTED_MODULE_3__["geoMercator"]()
            .center([80, 23])
            .scale(800)
            .translate([width / 2, height / 2]);
        var path = d3__WEBPACK_IMPORTED_MODULE_3__["geoPath"]().projection(projection);
        var svg = d3__WEBPACK_IMPORTED_MODULE_3__["selectAll"]("#map")
            .attr("width", width)
            .attr("height", height);
        var touchedPoint = null;
        var abc = this;
        var WorldData;
        this.http.get("https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json").subscribe(WorldJson => {
            this.isWait = false;
            WorldData = WorldJson;
            // console.log(indiaData);
            // console.log(topojson.feature(indiaData, indiaData.objects.Indian_States).features);
            svg.append("g").selectAll('path')
                .data(topojson__WEBPACK_IMPORTED_MODULE_4__["feature"](WorldData, WorldData.objects.countries).features)
                .enter()
                .append('path')
                .attr("d", function (abc) { return path(abc); })
                .style('fill', '#8cea8e')
                .style('stroke', 'cornsilk')
                .style('stroke-width', '1px')
                .style('opacity', '0.5')
                .on('mouseover', function (d) {
                d3__WEBPACK_IMPORTED_MODULE_3__["select"](this).style('fill', '#4c4b47').style('opacity', '1.0').style('stroke-width', '2px').attr('cursor', 'pointer').append("svg:title")
                    .text(function (d) { return d.properties.name; });
                abc.sendCountry(d.properties.name);
                console.log(d.properties.name);
            })
                .on('mouseleave', function () {
                abc.sendCountry('All');
                d3__WEBPACK_IMPORTED_MODULE_3__["select"](this).style('fill', '#8cea8e').style('stroke-width', '1px').style('opacity', '0.5');
            });
            svg.call(d3__WEBPACK_IMPORTED_MODULE_3__["zoom"]()
                .extent([[0, 0], [width, height]])
                .scaleExtent([1, 8])
                .on("zoom", zoomed));
            function zoomed() {
                svg.select('g').attr("transform", d3__WEBPACK_IMPORTED_MODULE_3__["event"].transform);
            }
            d3__WEBPACK_IMPORTED_MODULE_3__["select"]('#zoom-in').on('click', function () {
                d3__WEBPACK_IMPORTED_MODULE_3__["zoom"]()
                    .on('zoom', zoomed)
                    .scaleBy(svg.transition().duration(750), 1.3);
            });
            d3__WEBPACK_IMPORTED_MODULE_3__["select"]('#zoom-out').on('click', function () {
                d3__WEBPACK_IMPORTED_MODULE_3__["zoom"]()
                    .on('zoom', zoomed)
                    .scaleBy(svg.transition().duration(750), 1 / 1.3);
            });
        });
    }
};
ChroplethComponent.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], ChroplethComponent.prototype, "pushToParent", void 0);
ChroplethComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-chropleth',
        template: __webpack_require__(/*! raw-loader!./chropleth.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/chropleth/chropleth.component.html"),
        styles: [__webpack_require__(/*! ./chropleth.component.css */ "./src/app/components/chropleth/chropleth.component.css")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])
], ChroplethComponent);



/***/ }),

/***/ "./src/app/components/currentlocation.ts":
/*!***********************************************!*\
  !*** ./src/app/components/currentlocation.ts ***!
  \***********************************************/
/*! exports provided: CurrentLocation */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CurrentLocation", function() { return CurrentLocation; });
class CurrentLocation {
}


/***/ }),

/***/ "./src/app/components/doughnut-chart/doughnut-chart.component.css":
/*!************************************************************************!*\
  !*** ./src/app/components/doughnut-chart/doughnut-chart.component.css ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvZG91Z2hudXQtY2hhcnQvZG91Z2hudXQtY2hhcnQuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/components/doughnut-chart/doughnut-chart.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/components/doughnut-chart/doughnut-chart.component.ts ***!
  \***********************************************************************/
/*! exports provided: DoughnutChartComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DoughnutChartComponent", function() { return DoughnutChartComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_getdata_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/getdata.service */ "./src/app/services/getdata.service.ts");



let DoughnutChartComponent = class DoughnutChartComponent {
    constructor(_serviceData) {
        this._serviceData = _serviceData;
        this.doughnutChartLabels = ['Confirmed', 'Deaths', 'Recovered'];
        this.doughnutChartData = [];
        this.doughnutChartColors = [
            { backgroundColor: ["#566D7E", "#000000", "#6C7D55"] },
            { borderColor: ["#D68910", "#000000", "#006400"] }
        ];
        this.doughnutChartType = 'pie';
    }
    ngOnInit() {
    }
    ngOnChanges(changes) {
        console.log(this.data);
        this.doughnutChartData = [];
        this.doughnutChartData.push(this.data[0].cases.total, this.data[0].deaths.total, this.data[0].cases.recovered);
    }
};
DoughnutChartComponent.ctorParameters = () => [
    { type: _services_getdata_service__WEBPACK_IMPORTED_MODULE_2__["GetdataService"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], DoughnutChartComponent.prototype, "data", void 0);
DoughnutChartComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-doughnut-chart',
        template: __webpack_require__(/*! raw-loader!./doughnut-chart.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/doughnut-chart/doughnut-chart.component.html"),
        styles: [__webpack_require__(/*! ./doughnut-chart.component.css */ "./src/app/components/doughnut-chart/doughnut-chart.component.css")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_getdata_service__WEBPACK_IMPORTED_MODULE_2__["GetdataService"]])
], DoughnutChartComponent);



/***/ }),

/***/ "./src/app/components/landing-page/landing-page.component.css":
/*!********************************************************************!*\
  !*** ./src/app/components/landing-page/landing-page.component.css ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvbGFuZGluZy1wYWdlL2xhbmRpbmctcGFnZS5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/components/landing-page/landing-page.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/components/landing-page/landing-page.component.ts ***!
  \*******************************************************************/
/*! exports provided: LandingPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LandingPageComponent", function() { return LandingPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_getdata_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/getdata.service */ "./src/app/services/getdata.service.ts");



let LandingPageComponent = class LandingPageComponent {
    constructor(_dataService) {
        this._dataService = _dataService;
        this.send = false;
        this.AllCountriesData = [];
        this.barChartValue = [];
        this.name = 'World';
    }
    ngOnInit() {
        this.data = [...this._dataService.getSavedData()];
        this.barChartValue = [...this.data.slice(3, 8)];
        this.doughnut = (this._dataService.getDoughnutData());
        console.log(this.doughnut);
        this.setFlag();
    }
    setFlag() {
        this.send = true;
    }
    receiveMessage(a) {
        if (a == 'All')
            this.name = 'World';
        else
            this.name = a;
        if (a == 'United States of America') {
            a = 'USA';
            this.name = 'USA';
        }
        else if (a == 'Sri Lanka') {
            a = 'Sri-Lanka';
        }
        this.doughnut = [];
        this.doughnut = this.data.find((datas) => a == datas.country);
    }
};
LandingPageComponent.ctorParameters = () => [
    { type: _services_getdata_service__WEBPACK_IMPORTED_MODULE_2__["GetdataService"] }
];
LandingPageComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-landing-page',
        template: __webpack_require__(/*! raw-loader!./landing-page.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/landing-page/landing-page.component.html"),
        styles: [__webpack_require__(/*! ./landing-page.component.css */ "./src/app/components/landing-page/landing-page.component.css")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_getdata_service__WEBPACK_IMPORTED_MODULE_2__["GetdataService"]])
], LandingPageComponent);



/***/ }),

/***/ "./src/app/components/navbar/navbar.component.css":
/*!********************************************************!*\
  !*** ./src/app/components/navbar/navbar.component.css ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n#nav :hover {\r\n  cursor: pointer;\r\n}\r\nbody {\r\n  font-size: 20px;\r\n  border-style: ridge\r\n}\r\n.navbar{\r\n  position: relative;\r\n}\r\n@-webkit-keyframes rotation {\r\n  from {\r\n    -webkit-transform: rotate(0deg);\r\n            transform: rotate(0deg);\r\n  }\r\n  to {\r\n    -webkit-transform: rotate(359deg);\r\n            transform: rotate(359deg);\r\n  }\r\n}\r\n@keyframes rotation {\r\n  from {\r\n    -webkit-transform: rotate(0deg);\r\n            transform: rotate(0deg);\r\n  }\r\n  to {\r\n    -webkit-transform: rotate(359deg);\r\n            transform: rotate(359deg);\r\n  }\r\n}\r\n.rotate {\r\n  -webkit-animation: rotation 8s infinite linear;\r\n          animation: rotation 8s infinite linear;\r\n}\r\n\r\n\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9uYXZiYXIvbmF2YmFyLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUNBO0VBQ0UsZUFBZTtBQUNqQjtBQUNBO0VBQ0UsZUFBZTtFQUNmO0FBQ0Y7QUFDQTtFQUNFLGtCQUFrQjtBQUNwQjtBQUNBO0VBQ0U7SUFDRSwrQkFBdUI7WUFBdkIsdUJBQXVCO0VBQ3pCO0VBQ0E7SUFDRSxpQ0FBeUI7WUFBekIseUJBQXlCO0VBQzNCO0FBQ0Y7QUFQQTtFQUNFO0lBQ0UsK0JBQXVCO1lBQXZCLHVCQUF1QjtFQUN6QjtFQUNBO0lBQ0UsaUNBQXlCO1lBQXpCLHlCQUF5QjtFQUMzQjtBQUNGO0FBQ0E7RUFDRSw4Q0FBc0M7VUFBdEMsc0NBQXNDO0FBQ3hDIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9uYXZiYXIvbmF2YmFyLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuI25hdiA6aG92ZXIge1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5ib2R5IHtcclxuICBmb250LXNpemU6IDIwcHg7XHJcbiAgYm9yZGVyLXN0eWxlOiByaWRnZVxyXG59XHJcbi5uYXZiYXJ7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG59XHJcbkBrZXlmcmFtZXMgcm90YXRpb24ge1xyXG4gIGZyb20ge1xyXG4gICAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7XHJcbiAgfVxyXG4gIHRvIHtcclxuICAgIHRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7XHJcbiAgfVxyXG59XHJcbi5yb3RhdGUge1xyXG4gIGFuaW1hdGlvbjogcm90YXRpb24gOHMgaW5maW5pdGUgbGluZWFyO1xyXG59XHJcblxyXG5cclxuIl19 */"

/***/ }),

/***/ "./src/app/components/navbar/navbar.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/components/navbar/navbar.component.ts ***!
  \*******************************************************/
/*! exports provided: NavbarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NavbarComponent", function() { return NavbarComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_getdata_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/getdata.service */ "./src/app/services/getdata.service.ts");



let NavbarComponent = class NavbarComponent {
    constructor(_dataService) {
        this._dataService = _dataService;
        this.send = false;
    }
    ngOnInit() {
        this._dataService.getLiveData().subscribe((data) => {
            data.sort((a, b) => { return b.cases.total - a.cases.total; });
            this._dataService.saveData(data);
            this.send = true;
        });
    }
};
NavbarComponent.ctorParameters = () => [
    { type: _services_getdata_service__WEBPACK_IMPORTED_MODULE_2__["GetdataService"] }
];
NavbarComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-navbar',
        template: __webpack_require__(/*! raw-loader!./navbar.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/navbar/navbar.component.html"),
        styles: [__webpack_require__(/*! ./navbar.component.css */ "./src/app/components/navbar/navbar.component.css")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_getdata_service__WEBPACK_IMPORTED_MODULE_2__["GetdataService"]])
], NavbarComponent);



/***/ }),

/***/ "./src/app/components/tablerep/tablerep.component.css":
/*!************************************************************!*\
  !*** ./src/app/components/tablerep/tablerep.component.css ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\nbody {\r\nmargin-top: 15px;\r\n   border-style:outset;\r\n       font-size: 15px;\r\n  }\r\n  .table{\r\n      border-radius: 15px\r\n  }\r\n  #search{\r\n  border-radius: 10px;\r\n  border-style: ridge\r\n}\r\n  th{\r\n  border-radius: 15px;\r\n  font-size: 18px\r\n}\r\n\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy90YWJsZXJlcC90YWJsZXJlcC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFDQTtBQUNBLGdCQUFnQjtHQUNiLG1CQUFtQjtPQUNmLGVBQWU7RUFDcEI7RUFDQTtNQUNJO0VBQ0o7RUFDRjtFQUNFLG1CQUFtQjtFQUNuQjtBQUNGO0VBQ0E7RUFDRSxtQkFBbUI7RUFDbkI7QUFDRiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvdGFibGVyZXAvdGFibGVyZXAuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5ib2R5IHtcclxubWFyZ2luLXRvcDogMTVweDtcclxuICAgYm9yZGVyLXN0eWxlOm91dHNldDtcclxuICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICB9XHJcbiAgLnRhYmxle1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAxNXB4XHJcbiAgfVxyXG4jc2VhcmNoe1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgYm9yZGVyLXN0eWxlOiByaWRnZVxyXG59XHJcbnRoe1xyXG4gIGJvcmRlci1yYWRpdXM6IDE1cHg7XHJcbiAgZm9udC1zaXplOiAxOHB4XHJcbn1cclxuXHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/components/tablerep/tablerep.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/components/tablerep/tablerep.component.ts ***!
  \***********************************************************/
/*! exports provided: TablerepComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TablerepComponent", function() { return TablerepComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_getdata_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/getdata.service */ "./src/app/services/getdata.service.ts");



let TablerepComponent = class TablerepComponent {
    constructor(_serviceData) {
        this._serviceData = _serviceData;
        this.countryPopulation = [];
    }
    ngOnInit() {
        console.log(this.data);
        this.data = [...this._serviceData.getSavedData().slice(3)];
        this.Filterdata = this.data;
    }
    set enteredtext(newValue) {
        this._enteredtext = newValue;
        this.Filterdata = this._enteredtext ? this.filterdata(this._enteredtext) : this.data;
    }
    filterdata(filtertext) {
        // console.log(enteredtext);
        return this.data.filter((datas) => (datas.country.toLowerCase()).indexOf(filtertext.toLowerCase()) !== -1);
    }
};
TablerepComponent.ctorParameters = () => [
    { type: _services_getdata_service__WEBPACK_IMPORTED_MODULE_2__["GetdataService"] }
];
TablerepComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-tablerep',
        template: __webpack_require__(/*! raw-loader!./tablerep.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/tablerep/tablerep.component.html"),
        styles: [__webpack_require__(/*! ./tablerep.component.css */ "./src/app/components/tablerep/tablerep.component.css")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_getdata_service__WEBPACK_IMPORTED_MODULE_2__["GetdataService"]])
], TablerepComponent);



/***/ }),

/***/ "./src/app/services/getdata.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/getdata.service.ts ***!
  \*********************************************/
/*! exports provided: GetdataService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetdataService", function() { return GetdataService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");



let GetdataService = class GetdataService {
    constructor(_http) {
        this._http = _http;
        this.AllCountriesData = [];
    }
    getLiveData() {
        const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({ "Access-Control-Allow-Credentials": "true" });
        return this._http.get("http://localhost:8080/users", { headers });
    }
    saveData(data) {
        this.AllCountriesData = [...data];
    }
    getDoughnutData() {
        return this.AllCountriesData[0];
    }
    getSavedData() {
        return this.AllCountriesData;
    }
};
GetdataService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
GetdataService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
], GetdataService);



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! hammerjs */ "./node_modules/hammerjs/hammer.js");
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\ParasKumar\Downloads\covid19disaster\client\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map